﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoList
{
    public class Datos_Tarea1
    {   //encapsulamos los datos que usaremos
        public string NombreUsuario { get; set; }
        public string NombreTarea { get; set; }
        public string Hora { get; set; }
        public DateTime fecha { get; set; }
        public string Estatus { get; set; }

    }
}
